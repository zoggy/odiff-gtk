odiff-gtk
=========

OCaml library to display and merge diffs using Lablgtk.

More details on http://zoggy.github.io/odiff-gtk .
